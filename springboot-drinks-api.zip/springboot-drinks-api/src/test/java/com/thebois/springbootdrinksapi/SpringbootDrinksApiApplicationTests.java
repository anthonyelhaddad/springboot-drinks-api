package com.thebois.springbootdrinksapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDrinksApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
